# Implement Task


You are implementing one well-scoped task. The caller has delegated to you via `agd`. You may write files in `/Volumes/Home/Users/wen/repos/sshi` (the operator has enabled the required bypass flags in your `agd` config).

- **Repo:** `/Volumes/Home/Users/wen/repos/sshi`
- **Spec (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/specs/2026-05-26-tui-operate-refactor-design.md`
- **Plan (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/plans/2026-05-26-tui-operate-refactor.md`
- **Stage:** task 11b: View Log specific-params editing

**Load these skills before starting the task** (via your `Skill` tool if running inside Claude Code; otherwise read `~/.claude/skills/<name>/SKILL.md` and follow them): `test-driven-development`, `verification-before-completion`.

## Task

Task 11b: Add an editable specific-params panel to the View tab for the LOG operation only, with focus-zone navigation and live refresh. SCOPE: ONLY log params (last, errors, action, since, host) — all feed log_core. Checkout history/since and out are NON-wireable (checkout::run ignores _history/_since; no history fetch exists) so do NOT build them; Checkout/List have NO specific params. READ FIRST: src/tui/app.rs View key handling (~1809-1882: Left/Right cycle view_op, f filter, Up/Down/PgUp/PgDn/Home/End scroll via checkout_viewport; note the guard at ~1853 'checkout_viewport.selected==0'), refresh_view (~964), the render dispatch View block (~1914-1960), src/tui/tabs/view_tab.rs (ViewRenderData + render_view 3-chunk layout selector/summary/result), src/tui/components/input_field.rs (InputField: value:String, mode:InputMode, new/activate/confirm/cancel/handle_key/render), how sync text inputs are activated and how active-input key routing works in app.rs (the suspend block routing keys to an active InputField), and crate::cli::ActionFilter {Sync,Run,Exec,Check}. IMPLEMENT: (1) App fields: log_action: Option<ActionFilter> (init None), log_last_input: InputField (init self.log_last.to_string()), log_since_input: InputField, log_host_input: InputField (init empty). Keep existing log_last:usize and log_errors:bool. (2) Add enum ViewFocus and a self.view_focus: ViewFocus. Model focus as an ordered list of stops built per op: Checkout/List => [OpSelector, TargetSummary, Result]; Log => [OpSelector, Specific(0..=4), Result] (TargetSummary skipped for Log since its target is inert). Represent stops so Up/Down can walk them. The 5 Log specific fields in order: 0=last(text),1=errors(bool),2=action(enum),3=since(text),4=host(text). (3) view_tab render: add a specific-params chunk BETWEEN target-summary and result, rendered ONLY for Log (height = 5; for Checkout/List height 0 so layout is unchanged). Add fields to ViewRenderData to carry what the panel needs: the three InputField refs (log_last_input/log_since_input/log_host_input), log_errors: bool, an action display string, and which specific field index is focused (Option<usize>, None when focus is not in the panel). Render each field row in the Config field style: text inputs via InputField::render with focused flag; errors as a [x]/[ ] checkbox; action as 'action: <value>' with the focused highlight. Recompute the result-area set_dims height to account for the 5-row panel when view_op==Log (result height = inner - selector2 - summary1 - panel5; for checkout subtract its table header as before). (4) Navigation/editing in app.rs View key handling: Up/Down move between focus stops (within Log, across the 5 specific fields). When focus==Result, Up/Down scroll the result (reuse checkout_viewport.move_up/move_down); leaving Result upward: if scroll already at top (selected==0/scroll_y==0) move focus to the previous stop, else scroll. Keep PgUp/PgDn/Home/End always scrolling the result. Left/Right on OpSelector cycle view_op (existing); Left/Right on Specific(action) cycle the action enum through [all(None),sync,run,exec,check] and set view_dirty. Space on Specific(errors) toggles log_errors and sets view_dirty. Enter on Specific(last/since/host) activates that InputField; route keys to the active input (mirror existing active-input handling); on confirm: for last parse the value into self.log_last (ignore/keep old on parse failure), then set view_dirty; for since/host the value is read at query time. f/Enter on TargetSummary opens the filter popup but ONLY for Checkout/List (already inert for Log). (5) refresh_view Log arm: pass last=self.log_last, since = non-empty trimmed log_since_input.value else None, host = non-empty trimmed log_host_input.value else None, action = self.log_action.clone(), errors = self.log_errors. (6) For apply of bool/enum prefer routing through operate_schema::apply_view_specific where it fits (errors,action), consistent with Task 9; text inputs handled directly. (7) cargo build --features tui compiles with NO warnings; cargo test --features tui passes; add a small unit test if an App-level test harness exists, else rely on build. Commit 'feat(tui): View Log specific-params editing (last/errors/action/since/host)'. CRITICAL: do NOT regress the 11a scroll behavior for checkout/list; do NOT build checkout history/since or out. Surgical; leave Operate/Config and unrelated in-flight edits alone.

## Rules

1. Work in `/Volumes/Home/Users/wen/repos/sshi`. Do not modify files outside what the task lists unless the task says to.
2. Follow any TDD steps the task names exactly: failing test → run → implement → run → commit.
3. Use the commit message the task specifies verbatim, if any.
4. If a step is ambiguous or the task contradicts the spec, STOP and return `status: BLOCKED` with notes.
5. Inspect-only commands are fine; do not let them mutate workspace state.

## Output contract

Your response MUST **end with** this YAML block (delimited by `---`, after any progress notes):

```yaml
---
status: COMPLETED | BLOCKED
files_changed:
  - <path relative to /Volumes/Home/Users/wen/repos/sshi>
notes: |
  <free-text summary; required even when COMPLETED>
---
```

- `COMPLETED`: all steps run, tests pass, commit created.
- `BLOCKED`: explain in `notes` (missing context, plan conflict, environment).
- `files_changed`: if unsure, paste `git diff --name-only HEAD`.
