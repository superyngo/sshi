All 12 steps completed. TDD cycle verified: both new tests were written first, watched fail for the correct reason (missing field / missing function), then made to pass with minimal code. Full suite green at 154 tests.

---
status: COMPLETED
files_changed:
  - src/cli.rs
  - src/commands/mod.rs
  - src/tui/entry.rs
  - src/tui/app.rs
notes: |
  Implemented Task 1 (common --skip target filter) following all 12 steps exactly.
  - Added `skip: Vec<String>` to `TargetArgs` with `#[arg(long, value_delimiter = ',')]`
  - Added `filter_skipped` helper in `commands/mod.rs` (module-private, skips hosts by name, no-op for unknowns, early return for empty skip list)
  - Added `skip` field to `Context` struct, wired in all constructors: `new` (from target.skip.clone), `from_tui_parts` (Vec::new), `new_without_targets` (Vec::new)
  - Applied `filter_skipped` in `resolve_hosts` before the empty-set check
  - Also wired `skip: Vec::new()` in `tui/entry.rs` and `tui/app.rs` Context constructions
  - Two new tests: `skip_parses_as_comma_list_on_check` (parse test) and `filter_skipped_removes_named_hosts` (unit test)
  - Full suite: 154 passed (152 baseline + 2 new)
  - Committed with exact message from plan step 12
---
