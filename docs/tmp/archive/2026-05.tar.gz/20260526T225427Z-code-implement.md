# Implement Task


You are implementing one well-scoped task. The caller has delegated to you via `agd`. You may write files in `/Volumes/Home/Users/wen/repos/sshi` (the operator has enabled the required bypass flags in your `agd` config).

- **Repo:** `/Volumes/Home/Users/wen/repos/sshi`
- **Spec (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/specs/2026-05-26-tui-operate-refactor-design.md`
- **Plan (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/plans/2026-05-26-tui-operate-refactor.md`
- **Stage:** task 6: extend OperateState, drop run_yes

**Load these skills before starting the task** (via your `Skill` tool if running inside Claude Code; otherwise read `~/.claude/skills/<name>/SKILL.md` and follow them): `test-driven-development`, `verification-before-completion`.

## Task

Task 6 from the plan: Extend OperateState, add ViewOperationKind, drop run_yes. Follow plan Task 6 Steps 1-6 exactly. Step1: add tests operate_state_extended_round_trips and view_operation_kind_defaults_checkout in src/tui/state/persist.rs. Step2: verify fail. Step3: in persist.rs remove run_yes from OperateState and add new fields exactly per the plan snippet (run_sudo, exec_sudo, exec_keep, sync_mode, sync_dry_run, check_dry_run, run_dry_run, exec_dry_run, view_operation: ViewOperationKind, checkout_history: bool, log_last: usize, log_errors: bool) keeping #[serde(default)]; preserve any EXISTING OperateState fields not listed (e.g. operation: OperationKind) — only ADD the new ones and REMOVE run_yes. Add the ViewOperationKind enum (Checkout default, List, Log) with the derives in the plan snippet. Step4: fix OperateState construction in app.rs: from_context sets run_yes from persisted.operate.run_yes — remove that line and remove the run_yes field from App (struct + constructor). grep -rn run_yes src/tui/ and delete the App.run_yes field, its constructor init, and any read. For the OperateRenderData.run_yes construction site (removed fully in Task 8), if needed to compile NOW leave a 'run_yes: false' literal at the render-data construction site only. Step5: run 'cargo test --features tui -p sshi operate_state view_operation && cargo build --features tui' confirm pass+compile. Step6: commit 'feat(tui): extend OperateState for view ops; drop dead run_yes'. IMPORTANT before editing: read the current OperateState definition and the existing field names so you preserve existing fields and match the real OperationKind/SyncMode type paths. Build/test tui feature only. Leave unrelated in-flight edits alone.

## Rules

1. Work in `/Volumes/Home/Users/wen/repos/sshi`. Do not modify files outside what the task lists unless the task says to.
2. Follow any TDD steps the task names exactly: failing test → run → implement → run → commit.
3. Use the commit message the task specifies verbatim, if any.
4. If a step is ambiguous or the task contradicts the spec, STOP and return `status: BLOCKED` with notes.
5. Inspect-only commands are fine; do not let them mutate workspace state.

## Output contract

Your response MUST **end with** this YAML block (delimited by `---`, after any progress notes):

```yaml
---
status: COMPLETED | BLOCKED
files_changed:
  - <path relative to /Volumes/Home/Users/wen/repos/sshi>
notes: |
  <free-text summary; required even when COMPLETED>
---
```

- `COMPLETED`: all steps run, tests pass, commit created.
- `BLOCKED`: explain in `notes` (missing context, plan conflict, environment).
- `files_changed`: if unsure, paste `git diff --name-only HEAD`.
