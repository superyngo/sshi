# Implement Task


You are implementing one well-scoped task. The caller has delegated to you via `agd`. You may write files in `/Volumes/Home/Users/wen/repos/sshi` (the operator has enabled the required bypass flags in your `agd` config).

- **Repo:** `/Volumes/Home/Users/wen/repos/sshi`
- **Spec (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/specs/2026-05-26-tui-operate-refactor-design.md`
- **Plan (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/plans/2026-05-26-tui-operate-refactor.md`
- **Stage:** task 8b: wire sync source input

**Load these skills before starting the task** (via your `Skill` tool if running inside Claude Code; otherwise read `~/.claude/skills/<name>/SKILL.md` and follow them): `test-driven-development`, `verification-before-completion`.

## Task

Wire the dormant sync 'source' input into the TUI (scope: 'wireable-only' per user decision; do NOT add dry_run for check/run/exec or 'out' anywhere). Context: App has a dormant field '_sync_source_input: InputField' (src/tui/app.rs ~line 149) that is never surfaced. commands::sync::sync_core's 4th param is 'cli_source: Option<&str>' (a source-path override); the TUI currently passes None at app.rs:797. GOAL: let the user edit a source path in the sync param panel and pass it to sync_core. STEPS: (1) Rename '_sync_source_input' to 'sync_source_input' across app.rs (it is now used; drop the underscore). (2) Add a ParamPanelField::SyncSourceInput variant (read the ParamPanelField enum + the sync param navigation/cycling order around app.rs:1410-1470 and the activation handler near app.rs:1587 where sync_adhoc_input.activate() is called) and insert SyncSourceInput into the sync param focus order, mirroring how SyncAdHocInput is navigated and activated (activate to type, Enter/Esc to commit/cancel — follow the EXACT pattern sync_adhoc_input uses, but source is a single value not a pushed list: typing edits the field value directly, no Enter-to-push). (3) Add 'sync_source_input: &'a InputField' to OperateRenderData (operate_tab.rs) and pass '&self.sync_source_input' at the construction site (app.rs ~2069). (4) In render_sync_params (operate_tab.rs), add a source input row (a Constraint::Length(3) text-input rendered via InputField::render like sync_adhoc_input, labeled 'Source override (optional)') focused when param_field==SyncSourceInput; render it for BOTH sync modes; update the sync_chunks constraints and the param_rows count in render_operate accordingly. (5) In execute_sync (app.rs ~741-797), replace the None for cli_source with: a non-empty trimmed sync_source_input.value → Some(&value), else None. (6) 'cargo build --features tui' compiles; 'cargo test --features tui' passes. Commit 'feat(tui): wire sync source override input'. CRITICAL: read the real ParamPanelField enum, InputField API (.value/.activate()/.render()/InputMode), and the existing sync_adhoc_input handling before editing; match those patterns exactly. Surgical — touch only sync-source wiring. Leave unrelated in-flight edits and the View/Checkout code alone.

## Rules

1. Work in `/Volumes/Home/Users/wen/repos/sshi`. Do not modify files outside what the task lists unless the task says to.
2. Follow any TDD steps the task names exactly: failing test → run → implement → run → commit.
3. Use the commit message the task specifies verbatim, if any.
4. If a step is ambiguous or the task contradicts the spec, STOP and return `status: BLOCKED` with notes.
5. Inspect-only commands are fine; do not let them mutate workspace state.

## Output contract

Your response MUST **end with** this YAML block (delimited by `---`, after any progress notes):

```yaml
---
status: COMPLETED | BLOCKED
files_changed:
  - <path relative to /Volumes/Home/Users/wen/repos/sshi>
notes: |
  <free-text summary; required even when COMPLETED>
---
```

- `COMPLETED`: all steps run, tests pass, commit created.
- `BLOCKED`: explain in `notes` (missing context, plan conflict, environment).
- `files_changed`: if unsure, paste `git diff --name-only HEAD`.
