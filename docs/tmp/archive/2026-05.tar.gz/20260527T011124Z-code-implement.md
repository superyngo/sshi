# Implement Task


You are implementing one well-scoped task. The caller has delegated to you via `agd`. You may write files in `/Volumes/Home/Users/wen/repos/sshi` (the operator has enabled the required bypass flags in your `agd` config).

- **Repo:** `/Volumes/Home/Users/wen/repos/sshi`
- **Spec (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/specs/2026-05-26-tui-operate-refactor-design.md`
- **Plan (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/plans/2026-05-26-tui-operate-refactor.md`
- **Stage:** task 9: route Operate toggles via operate_schema

**Load these skills before starting the task** (via your `Skill` tool if running inside Claude Code; otherwise read `~/.claude/skills/<name>/SKILL.md` and follow them): `test-driven-development`, `verification-before-completion`.

## Task

Task 9 (scope: wireable-only): Route the Operate tab existing param toggles through operate_schema::apply_specific so they edit exactly like Config fields (spec Goal 2). BEHAVIOR-PRESERVING refactor — UX must NOT change. Context: the Space handler in src/tui/app.rs (around lines 1577-1608) currently flips toggles directly: (Run,Sudo) sets run_sudo, (Exec,Sudo) sets exec_sudo, (Exec,SecondFlag) sets exec_keep, (Sync,SyncModeToggle) sets sync_mode, (Sync,SyncDryRun) sets sync_dry_run. STEPS: (1) Add a helper method on App named apply_operate_toggle(&mut self, op, key, val) that builds an operate_schema::OpSpecific and calls operate_schema::apply_specific(&mut s, op, key, val). NOTE OpSpecific has 8 fields: sudo, keep, dry_run, sync_mode, checkout_history, log_last, log_errors, log_action. Map the ones App has to real fields per op: Run uses sudo = and mut self.run_sudo; Exec uses sudo = and mut self.exec_sudo and keep = and mut self.exec_keep; Sync uses sync_mode = and mut self.sync_mode and dry_run = and mut self.sync_dry_run. For dry_run on Run/Exec (NOT rendered this cycle) and for the view-only slots checkout_history/log_last/log_errors/log_action that App does NOT have yet (they arrive in Task 11), pass and mut throwaway scratch let-bindings; apply_specific for OperationKind Run/Exec/Sync never writes those, so scratch is safe. Since sudo maps to a different App field per op, build the OpSpecific inside a per-op branch (a match on op) so the borrows are correct. (2) Replace each direct toggle in the Space handler: compute the new value as a string (true/false for bools; for sync mode compute the next mode string config or adhoc) and call self.apply_operate_toggle(op, key, new_val) then self.save_state() as before. Key strings MUST match apply_specific: sudo, keep, dry_run, mode. (3) Navigation already correct — do NOT change navigation. Keep InputField text editing as-is. (4) Add a unit test only if an existing App-level key-handling test pattern exists; otherwise rely on existing operate_schema apply_ tests plus build. (5) cargo build --features tui compiles with no warnings; cargo test --features tui passes. Commit message: feat(tui): Operate param toggles via operate_schema (Config-consistent). CRITICAL: do NOT add dry_run toggles for check/run/exec or out (deferred). Surgical; leave View/Checkout and unrelated in-flight edits alone.

## Rules

1. Work in `/Volumes/Home/Users/wen/repos/sshi`. Do not modify files outside what the task lists unless the task says to.
2. Follow any TDD steps the task names exactly: failing test → run → implement → run → commit.
3. Use the commit message the task specifies verbatim, if any.
4. If a step is ambiguous or the task contradicts the spec, STOP and return `status: BLOCKED` with notes.
5. Inspect-only commands are fine; do not let them mutate workspace state.

## Output contract

Your response MUST **end with** this YAML block (delimited by `---`, after any progress notes):

```yaml
---
status: COMPLETED | BLOCKED
files_changed:
  - <path relative to /Volumes/Home/Users/wen/repos/sshi>
notes: |
  <free-text summary; required even when COMPLETED>
---
```

- `COMPLETED`: all steps run, tests pass, commit created.
- `BLOCKED`: explain in `notes` (missing context, plan conflict, environment).
- `files_changed`: if unsure, paste `git diff --name-only HEAD`.
