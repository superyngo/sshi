---
status: COMPLETED
files_changed:
  - src/tui/app.rs
  - src/tui/tabs/view_tab.rs
notes: |
  Implemented View Log specific-params editing panel with focus-zone navigation and live refresh:
  - Added `ViewFocus` enum with `OpSelector`, `Specific(usize)`, and `Result` variants, plus a `stops()` method that returns ordered focus stops per operation (Checkout/List: [OpSelector, Result]; Log: [OpSelector, Specific(0..4), Result]).
  - Added App fields: `log_action: Option<ActionFilter>`, `log_last_input: InputField`, `log_since_input: InputField`, `log_host_input: InputField`, `view_focus: ViewFocus`.
  - Added 5-row specific-params panel in view_tab.rs between target-summary and result area, rendered only for Log (last text input, errors checkbox, action enum, since text input, host text input).
  - Updated ViewRenderData with new fields to carry specific-params state to the renderer.
  - Implemented focus-zone Up/Down navigation: Up at Result top escapes to previous stop; Down at non-Result stops advances; Result always scrolls. OpSelector Left/Right cycles view_op; Specific(2) Left/Right cycles action enum; Specific(1) Space toggles errors; Specific(0/3/4) Enter activates InputField with active-input key routing.
  - Updated refresh_view Log arm to pass `since`, `host`, and `action` params from the new inputs.
  - Checkout/List scroll behavior preserved — their stops are [OpSelector, Result] with no Specific fields.
  - Build: 0 warnings. Tests: 181 pass (2 new ViewFocus::stops unit tests added).
---
