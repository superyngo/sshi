---
status: COMPLETED
files_changed:
  - src/cli.rs
  - src/main.rs
  - src/commands/run.rs
notes: |
  Implemented --dry-run for `run` command via TDD:
  1. Added failing test `run_parses_dry_run` to cli.rs tests
  2. Added `dry_run: bool` #[arg(long)] field to Commands::Run after `sudo` in cli.rs
  3. Threaded `dry_run` through the Commands::Run match arm in main.rs
  4. Added `use crate::config::schema::ShellType` import to run.rs
  5. Added `dry_run` param to `run()` in run.rs with preview block before `let sink = PrinterSink`
  6. Dry-run prints `[dry-run] Command: {display}` then a "would execute" printer line per host, then returns Ok(())
  7. All 159 tests pass; binary verified: `run --all --dry-run "echo hi"` prints dry-run lines with no SSH/DB side effects
  8. Committed with message: `feat(run): add --dry-run flag to preview command without executing`
---
