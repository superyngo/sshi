---status: COMPLETED
files_changed:
  - src/tui/app.rs
notes: |
  Added `apply_operate_toggle` helper on App that builds per-operation OpSpecific structs (mapping sudo→run_sudo/exec_sudo, keep→exec_keep, sync_mode→sync_mode, dry_run→sync_dry_run) and delegates to operate_schema::apply_specific. Replaced the 5 direct-toggle arms in the Space handler with calls to apply_operate_toggle + save_state. Used scratch throwaway bindings for fields not yet owned by App (dry_run on Run/Exec, checkout_history, log_last, log_errors, log_action). Build passes with zero warnings; all 179 tests pass.
