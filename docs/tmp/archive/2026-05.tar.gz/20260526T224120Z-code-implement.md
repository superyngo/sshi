# Implement Task


You are implementing one well-scoped task. The caller has delegated to you via `agd`. You may write files in `/Volumes/Home/Users/wen/repos/sshi` (the operator has enabled the required bypass flags in your `agd` config).

- **Repo:** `/Volumes/Home/Users/wen/repos/sshi`
- **Spec (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/specs/2026-05-26-tui-operate-refactor-design.md`
- **Plan (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/plans/2026-05-26-tui-operate-refactor.md`
- **Stage:** task 4: skip row in FilterPopup

**Load these skills before starting the task** (via your `Skill` tool if running inside Claude Code; otherwise read `~/.claude/skills/<name>/SKILL.md` and follow them): `test-driven-development`, `verification-before-completion`.

## Task

Task 4 from the plan: Add the skip row to FilterPopup in src/tui/components/target_filter.rs. Follow plan Task 4 Steps 1-4. Step1: read the popup (grep enum/struct/fn render/fn handle_key/skip/serial/timeout) to find how the existing groups/hosts vec-edited rows and the serial/timeout rows are represented (the popup's internal focus enum + render rows + commit back to TargetFilterState). Step2: add a 'skip' editable row mirroring the EXISTING groups/hosts vec-entry handling (same input/commit mechanism), writing into TargetFilterState.skip on commit, rendered in the same style as the other vec rows. Keep it minimal and consistent with existing rows — do not invent a new editing mechanism. The TargetFilterState.skip field already exists (added in Task 3). Step3: 'cargo build --features tui' must compile. If the popup has a handle_key unit test, extend it to cover adding/removing a skip entry; otherwise no new test (verified via build + manual checklist later). Step4: commit 'feat(tui): add skip row to target filter popup'. Build with tui feature only. Surgical change; leave unrelated in-flight edits alone.

## Rules

1. Work in `/Volumes/Home/Users/wen/repos/sshi`. Do not modify files outside what the task lists unless the task says to.
2. Follow any TDD steps the task names exactly: failing test → run → implement → run → commit.
3. Use the commit message the task specifies verbatim, if any.
4. If a step is ambiguous or the task contradicts the spec, STOP and return `status: BLOCKED` with notes.
5. Inspect-only commands are fine; do not let them mutate workspace state.

## Output contract

Your response MUST **end with** this YAML block (delimited by `---`, after any progress notes):

```yaml
---
status: COMPLETED | BLOCKED
files_changed:
  - <path relative to /Volumes/Home/Users/wen/repos/sshi>
notes: |
  <free-text summary; required even when COMPLETED>
---
```

- `COMPLETED`: all steps run, tests pass, commit created.
- `BLOCKED`: explain in `notes` (missing context, plan conflict, environment).
- `files_changed`: if unsure, paste `git diff --name-only HEAD`.
