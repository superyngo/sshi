---
status: COMPLETED
files_changed:
  - src/cli.rs
  - src/main.rs
  - src/commands/run.rs
  - src/commands/exec.rs
  - src/tui/app.rs
notes: |
  Implemented Task 3 per plan: removed `-y/--yes` from `run` and `exec` CLI commands using TDD.
  Added failing tests `run_rejects_yes` and `exec_rejects_yes` first, then removed the `yes` flag blocks
  from `Commands::Run` and `Commands::Exec` in cli.rs, dropped `_yes`/`yes` params from `run_core`/`run`
  in run.rs and `exec_core`/`run` in exec.rs, updated match arms in main.rs, and removed the orphaned
  `let yes = self.run_yes;` binding plus fixed the `run_core` and `exec_core` call sites in app.rs.
  The `run_yes` field, checkbox, persistence, and help text were left untouched per spec.
  All 158 tests pass. TUI build confirmed clean. Committed with the exact message from Step 10.
---
