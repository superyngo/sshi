# Implement Task


You are implementing one well-scoped task. The caller has delegated to you via `agd`. You may write files in `/Volumes/Home/Users/wen/repos/sshi` (the operator has enabled the required bypass flags in your `agd` config).

- **Repo:** `/Volumes/Home/Users/wen/repos/sshi`
- **Spec (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/specs/2026-05-26-tui-operate-refactor-design.md`
- **Plan (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/plans/2026-05-26-tui-operate-refactor.md`
- **Stage:** task 8: rewrite render_operate Approach-B

**Load these skills before starting the task** (via your `Skill` tool if running inside Claude Code; otherwise read `~/.claude/skills/<name>/SKILL.md` and follow them): `test-driven-development`, `verification-before-completion`.

## Task

Task 8 from the plan (read plan section 'Task 8' in full): Rewrite render_operate to the Approach-B vertical stack: op selector -> target summary line -> specific params -> applicable entries -> execute button. Files: src/tui/tabs/operate_tab.rs and src/tui/app.rs (render_operate around line 2061, and OperateRenderData). CRITICAL FIRST: read operate_tab.rs in full and the App::render_operate construction site in app.rs to learn the REAL OperateRenderData fields, the OperateFocus enum variants, the Theme field names (the plan snippet uses data.theme.accent_operate, data.target_count, data.focus, data.target_filter with .mode/.groups/.hosts/.shell/.skip/.serial/.timeout, TargetFilterMode variants) — VERIFY each of these exists and adapt names to reality. Steps: (1) Remove run_yes from OperateRenderData and its render usage (the render_run_exec_params SecondFlag block for run): for run render only sudo + dry_run; the SecondFlag (keep) now applies to exec only. Remove the run_yes:false literal at the app.rs OperateRenderData construction site (added transitionally in Task 6) and the no-op SecondFlag/run_yes key arm if it now dangles. (2) Add a new render_target_summary fn (per the plan snippet, adapted to real field names) showing mode + skip + serial + timeout + target_count + '[f] filter', styled active when focus==TargetRow. (3) Keep existing render_run_exec_params/render_sync_params/render_applicable_entries/render_execute_button — only the sudo/keep/dry_run toggles' VALUES may now come from operate_schema but rendering is unchanged (do NOT rewire key handling here — that is Task 9). (4) Update the Layout constraints to the new vertical order (selector / target-summary 1 line / params / entries / execute). (5) 'cargo build --features tui' compiles; 'cargo test --features tui' passes. Then commit 'feat(tui): Operate tab Approach-B layout (summary line, no --yes)'. Build/test tui feature only. Surgical: do not change View/Checkout rendering or unrelated in-flight edits. Note exec keep flag must remain functional.

## Rules

1. Work in `/Volumes/Home/Users/wen/repos/sshi`. Do not modify files outside what the task lists unless the task says to.
2. Follow any TDD steps the task names exactly: failing test → run → implement → run → commit.
3. Use the commit message the task specifies verbatim, if any.
4. If a step is ambiguous or the task contradicts the spec, STOP and return `status: BLOCKED` with notes.
5. Inspect-only commands are fine; do not let them mutate workspace state.

## Output contract

Your response MUST **end with** this YAML block (delimited by `---`, after any progress notes):

```yaml
---
status: COMPLETED | BLOCKED
files_changed:
  - <path relative to /Volumes/Home/Users/wen/repos/sshi>
notes: |
  <free-text summary; required even when COMPLETED>
---
```

- `COMPLETED`: all steps run, tests pass, commit created.
- `BLOCKED`: explain in `notes` (missing context, plan conflict, environment).
- `files_changed`: if unsure, paste `git diff --name-only HEAD`.
