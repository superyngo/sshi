# Implement Task


You are implementing one well-scoped task. The caller has delegated to you via `agd`. You may write files in `/Volumes/Home/Users/wen/repos/sshi` (the operator has enabled the required bypass flags in your `agd` config).

- **Repo:** `/Volumes/Home/Users/wen/repos/sshi`
- **Spec (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/specs/2026-05-26-tui-operate-refactor-design.md`
- **Plan (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/plans/2026-05-26-tui-operate-refactor.md`
- **Stage:** task 11a: core View tab wiring

**Load these skills before starting the task** (via your `Skill` tool if running inside Claude Code; otherwise read `~/.claude/skills/<name>/SKILL.md` and follow them): `test-driven-development`, `verification-before-completion`.

## Task

Task 11a (first half of plan Task 11): Wire the View tab core into App — state fields, render dispatch, live refresh, and cycle/scroll/filter keys. Specific-param EDITING is a SEPARATE follow-up (11b) — do NOT add a specific-params render block or field editing now; just make checkout/list/log render with current/default params and auto-refresh on op switch. CONTEXT (read these first in src/tui/app.rs): App already has checkout_snapshots, checkout_all_snapshots, checkout_columns, checkout_viewport (scroll viewport), db_stale, maybe_reload_checkout() (~885), filter_checkout_snapshots() (~917-938). Render dispatch at ~1801: 'TabId::View => { self.maybe_reload_checkout(); self.render_checkout(chunks[1], frame); }'. The View key handlers are at ~1733-1765 (f:Filter at 1733; Up/Down/PgUp/PgDn/Home/End scroll via checkout_viewport). render_checkout method is at ~2423. Help text at ~2400 and footer hints at ~2527 still say 'Checkout'. Tab color at ~1840. STEPS: (1) Add App fields: view_op: ViewOperationKind (init from persisted.operate.view_operation), view_list: Option<crate::commands::list::ListData> (init None), view_log: Vec<crate::commands::log::LogRow> (init empty), view_dirty: bool (init true so first render refreshes), view_loading: bool (init false). Reuse existing checkout_snapshots/checkout_columns/checkout_viewport for the checkout payload and scroll. (2) Add fn refresh_view(&mut self): build a Context like maybe_reload_checkout does (config.clone(), db opened from self.config.settings.state_dir, timeout self from target_filter, mode build_target_mode(...), serial, skip self.target_filter.skip clone, verbose false — copy the exact Context field set used elsewhere). Match self.view_op: Checkout => call maybe_reload_checkout()+filter_checkout_snapshots() (existing path, leave as-is); List => self.view_list = Some(list_core(&ctx).unwrap_or_default()) [NOTE list_core returns Result]; Log => self.view_log = log_core(&ctx, last, None, None, None, errors).unwrap_or_default() where last = if persisted log_last==0 {20} else {persisted log_last} — for 11a use persisted.operate.log_last (stored in an App field self.log_last initialized with the 0->20 default) and self.log_errors from persisted; since/host/action are None in 11a. Set view_dirty=false at end. (3) Render dispatch: replace the TabId::View block to: if view_dirty { self.refresh_view(); } then build a view_tab::ViewRenderData { view_op, theme:&self.theme, navbar_focused:self.navbar_focused, loading:self.view_loading, checkout: Some((&self.checkout_snapshots, &self.checkout_columns)), list: self.view_list.as_ref(), log: Some(&self.view_log), result_scroll: <current scroll from checkout_viewport.selected or a view scroll> } and call view_tab::render_view(&data, chunks[1], frame). Only populate the payload for the ACTIVE view_op (set the others to None / empty as appropriate so render shows the right one). Remove the now-unused App::render_checkout method (its table logic now lives in view_tab::render_checkout_result). (4) Key handling for TabId::View: add Left/Right to cycle view_op (Checkout->List->Log->Checkout and reverse) and set view_dirty=true; keep the existing scroll keys (Up/Down/PgUp/PgDn/Home/End) operating on the result scroll; the 'f' filter key (1733) must be DISABLED (inert) when view_op==Log (log has no target); leave checkout/list using f. Clamp the result scroll to the active op's row count so it never scrolls past the end. (5) Update help text and footer: change the TabId::View strings at ~2400 and ~2527 from 'Checkout tab'/'Checkout' wording to 'View tab' describing checkout/list/log and the L/R op cycle (this completes the deferred rename from Task 5). (6) cargo build --features tui compiles with NO warnings (remove now-dead code your changes orphan, e.g. if render_checkout is fully removed); cargo test --features tui passes. Commit 'feat(tui): wire View tab core (checkout/list/log) with live refresh'. CRITICAL: list_core is fallible (Result) — use .unwrap_or_default(). Do NOT add specific-param editing (that is 11b). Surgical; leave Operate/Config and unrelated in-flight edits alone.

## Rules

1. Work in `/Volumes/Home/Users/wen/repos/sshi`. Do not modify files outside what the task lists unless the task says to.
2. Follow any TDD steps the task names exactly: failing test → run → implement → run → commit.
3. Use the commit message the task specifies verbatim, if any.
4. If a step is ambiguous or the task contradicts the spec, STOP and return `status: BLOCKED` with notes.
5. Inspect-only commands are fine; do not let them mutate workspace state.

## Output contract

Your response MUST **end with** this YAML block (delimited by `---`, after any progress notes):

```yaml
---
status: COMPLETED | BLOCKED
files_changed:
  - <path relative to /Volumes/Home/Users/wen/repos/sshi>
notes: |
  <free-text summary; required even when COMPLETED>
---
```

- `COMPLETED`: all steps run, tests pass, commit created.
- `BLOCKED`: explain in `notes` (missing context, plan conflict, environment).
- `files_changed`: if unsure, paste `git diff --name-only HEAD`.
