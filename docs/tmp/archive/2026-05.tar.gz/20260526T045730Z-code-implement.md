# Implement Task


You are implementing one well-scoped task. The caller has delegated to you via `agd`. You may write files in `/Volumes/Home/Users/wen/repos/ssync` (the operator has enabled the required bypass flags in your `agd` config).

- **Repo:** `/Volumes/Home/Users/wen/repos/ssync`
- **Spec (optional):** `docs/superpowers/specs/2026-05-26-cli-interface-unification-design.md`
- **Plan (optional):** `docs/superpowers/plans/2026-05-26-cli-interface-unification.md`
- **Stage:** task 1: common --skip target filter

**Load these skills before starting the task** (via your `Skill` tool if running inside Claude Code; otherwise read `~/.claude/skills/<name>/SKILL.md` and follow them): `test-driven-development`, `verification-before-completion`.

## Task

Implement Task 1 from the plan file (plan_path), Steps 1-12 exactly: add a comma-list --skip field to TargetArgs in src/cli.rs with a #[cfg(test)] parse test; add filter_skipped helper + unit test in src/commands/mod.rs; add skip: Vec<String> to Context and wire all three constructors (new=target.skip.clone, from_tui_parts=Vec::new, new_without_targets=Vec::new); apply filter in resolve_hosts before the empty-set check. Follow TDD (write failing test first). Run cargo test (expect 152+2). Commit with the exact message in Step 12. Do NOT touch project rename or TUI Config work.

## Rules

1. Work in `/Volumes/Home/Users/wen/repos/ssync`. Do not modify files outside what the task lists unless the task says to.
2. Follow any TDD steps the task names exactly: failing test → run → implement → run → commit.
3. Use the commit message the task specifies verbatim, if any.
4. If a step is ambiguous or the task contradicts the spec, STOP and return `status: BLOCKED` with notes.
5. Inspect-only commands are fine; do not let them mutate workspace state.

## Output contract

Your response MUST **end with** this YAML block (delimited by `---`, after any progress notes):

```yaml
---
status: COMPLETED | BLOCKED
files_changed:
  - <path relative to /Volumes/Home/Users/wen/repos/ssync>
notes: |
  <free-text summary; required even when COMPLETED>
---
```

- `COMPLETED`: all steps run, tests pass, commit created.
- `BLOCKED`: explain in `notes` (missing context, plan conflict, environment).
- `files_changed`: if unsure, paste `git diff --name-only HEAD`.
