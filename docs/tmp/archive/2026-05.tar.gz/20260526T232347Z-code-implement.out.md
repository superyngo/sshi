---
status: COMPLETED
files_changed:
  - src/tui/app.rs
  - src/tui/tabs/operate_tab.rs
notes: |
  Wired the dormant sync source input into the TUI:
  1. Renamed `_sync_source_input` → `sync_source_input` in app.rs (struct + init).
  2. Added `ParamPanelField::SyncSourceInput` variant to operate_tab.rs.
  3. Inserted SyncSourceInput into sync param navigation (Down: DryRun→Source→TargetRow; Up: TargetRow→Source→DryRun→AdHoc→Mode; TargetRow Up enters at SyncSourceInput).
  4. Added Enter key handler to activate `sync_source_input` (mirrors SyncAdHocInput pattern; no push-to-list since it's a single value).
  5. Added active field routing for SyncSourceInput in the key dispatch match.
  6. Added `sync_source_input: &'a InputField` to OperateRenderData and passed `&self.sync_source_input` at construction.
  7. In render_sync_params: added two new chunks (spacer + Length(3)), rendered source input via InputField::render labeled "Source override (optional)" for both sync modes; updated param_rows from 8 to 11.
  8. In execute_sync: captured `source_override: Option<String>` from trimmed input value and passed `source_override.as_deref()` instead of `None` to sync_core.
  Build: clean. Tests: 179 passed, 0 failed.
---
