# Implement Task


You are implementing one well-scoped task. The caller has delegated to you via `agd`. You may write files in `/Volumes/Home/Users/wen/repos/ssync` (the operator has enabled the required bypass flags in your `agd` config).

- **Repo:** `/Volumes/Home/Users/wen/repos/ssync`
- **Spec (optional):** `docs/superpowers/specs/2026-05-26-cli-interface-unification-design.md`
- **Plan (optional):** `docs/superpowers/plans/2026-05-26-cli-interface-unification.md`
- **Stage:** task 4: add run --dry-run

**Load these skills before starting the task** (via your `Skill` tool if running inside Claude Code; otherwise read `~/.claude/skills/<name>/SKILL.md` and follow them): `test-driven-development`, `verification-before-completion`.

## Task

Implement Task 4 from the plan file (plan_path), Steps 1-9 exactly. TDD: first add failing test run_parses_dry_run to the #[cfg(test)] mod tests in src/cli.rs. Then add a 'dry_run: bool' #[arg(long)] field to Commands::Run after sudo in cli.rs; thread dry_run through the Commands::Run match arm in src/main.rs; add dry_run param to the run handler in src/commands/run.rs and insert the dry-run preview block at the top of the body BEFORE 'let sink = PrinterSink;' (mirrors exec.rs:196) — print '[dry-run] Command: {display}' where display is sudo_wrap(ShellType::Sh, command) if sudo else command.to_string(), then resolve_hosts and print a 'would execute' printer line per host, then return Ok(()) before any SSH/DB side effect. Add 'use crate::config::schema::ShellType;' import to run.rs if missing. Build, run cargo test (expect all green), and verify on the real binary: 'cargo run -- run --all --dry-run echo hi' prints the dry-run lines with NO SSH/execution/operation_log row (or the no-hosts error if none configured). Commit with the exact message in Step 9.

## Rules

1. Work in `/Volumes/Home/Users/wen/repos/ssync`. Do not modify files outside what the task lists unless the task says to.
2. Follow any TDD steps the task names exactly: failing test → run → implement → run → commit.
3. Use the commit message the task specifies verbatim, if any.
4. If a step is ambiguous or the task contradicts the spec, STOP and return `status: BLOCKED` with notes.
5. Inspect-only commands are fine; do not let them mutate workspace state.

## Output contract

Your response MUST **end with** this YAML block (delimited by `---`, after any progress notes):

```yaml
---
status: COMPLETED | BLOCKED
files_changed:
  - <path relative to /Volumes/Home/Users/wen/repos/ssync>
notes: |
  <free-text summary; required even when COMPLETED>
---
```

- `COMPLETED`: all steps run, tests pass, commit created.
- `BLOCKED`: explain in `notes` (missing context, plan conflict, environment).
- `files_changed`: if unsure, paste `git diff --name-only HEAD`.
