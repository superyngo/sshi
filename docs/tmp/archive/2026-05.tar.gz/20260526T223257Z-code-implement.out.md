---
status: COMPLETED
files_changed:
  - src/commands/log.rs
notes: |
  Extracted log_core from log::run. Added LogRow struct and log_core() function that
  performs the DB query and returns Vec<LogRow>. Rewrote run() to format/print from
  rows, preserving exact existing stdout behavior. Added two tests:
  parse_since_relative_days and log_core_empty_db_returns_no_rows (built Context
  inline using public fields). All 165 tests pass. Committed with the specified
  message "refactor(log): extract log_core query fn from run".
---
