Task 7 complete.

```yaml
---
status: COMPLETED
files_changed:
  - src/tui/tabs/operate_schema.rs
  - src/tui/tabs/mod.rs
notes: |
  Created operate_schema.rs with OpSpecific<'a> struct, per-operation _specific_fields functions (check/run/exec/sync/checkout/log), apply_specific, and apply_view_specific. All functions use FieldDescriptor::scalar with the real FieldKind API (Bool, U64, Enum{variants:Vec<&'static str>}). Items wired for future use are annotated with #[allow(dead_code)]. Both TDD tests pass (check_specific_fields_has_dry_run, apply_run_sudo_toggles). Build and full test suite clean. Commit: 806dfb3.
---
```
