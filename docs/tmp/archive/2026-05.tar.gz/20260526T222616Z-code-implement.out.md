---
status: COMPLETED
files_changed:
  - src/commands/list.rs
notes: |
  Followed plan Task 1 steps exactly via TDD:
  1. Wrote failing test `list_core_returns_resolved_collections` — failed with E0425 (list_core not found).
  2. Added `ListData` struct (owned `Vec<HostEntry/CheckEntry/SyncEntry>`) and `list_core(ctx)` that clones borrowed refs from resolve_hosts/checks/syncs.
  3. Rewrote `run` as a thin printing wrapper calling `list_core`.
  4. Target test passes; full suite 163/163 passes, no regressions.
  5. Committed with verbatim message "refactor(list): extract list_core data fn from run".
  
  Note: resolve_hosts returns Vec<&HostEntry> (borrowed), so ListData fields use owned types via `.into_iter().cloned().collect()`.
---
