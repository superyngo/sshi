---
status: COMPLETED
files_changed:
  - src/cli.rs
  - src/main.rs
  - src/commands/check.rs
notes: |
  Implemented Task 5 (check --dry-run) following TDD. Added failing test `check_parses_dry_run`, verified red, added `dry_run: bool` field to `Commands::Check` in cli.rs (between target and output), threaded it through main.rs, added `dry_run` param to `check::run` handler and inserted preview block at top of body before the host_configs_empty_hint block. Preview resolves hosts, calls `build_host_check_configs`, and prints per-host lines showing "would collect: <metrics>" or "no checks apply", then returns Ok(()) before any SSH or DB writes. Verified on real binary: `check --all --dry-run` prints per-host previews; `log --last 5` confirms no DB writes. All 160 tests pass. Committed with verbatim message from plan.
---
