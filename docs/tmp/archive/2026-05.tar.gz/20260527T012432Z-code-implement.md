# Implement Task


You are implementing one well-scoped task. The caller has delegated to you via `agd`. You may write files in `/Volumes/Home/Users/wen/repos/sshi` (the operator has enabled the required bypass flags in your `agd` config).

- **Repo:** `/Volumes/Home/Users/wen/repos/sshi`
- **Spec (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/specs/2026-05-26-tui-operate-refactor-design.md`
- **Plan (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/plans/2026-05-26-tui-operate-refactor.md`
- **Stage:** task 10: create view_tab.rs

**Load these skills before starting the task** (via your `Skill` tool if running inside Claude Code; otherwise read `~/.claude/skills/<name>/SKILL.md` and follow them): `test-driven-development`, `verification-before-completion`.

## Task

Task 10 from the plan (read plan section 'Task 10'): Create src/tui/tabs/view_tab.rs with a ViewRenderData struct, render_view entry point, and three result renderers (checkout/list/log) as PURE functions of the data structs. Register 'pub mod view_tab;' in src/tui/tabs/mod.rs. CRITICAL FIRST: read (a) the existing App::render_checkout in src/tui/app.rs to learn how the checkout table is currently rendered (you will reproduce that logic as view_tab::render_checkout_result using the pub(crate) helpers extract_metric_value, metric_header, metric_width, format_relative_time, DisplayColumns, HostSnapshot, fetch_latest_snapshots from crate::commands::checkout), (b) crate::commands::list::ListData and list::run for the list text layout, (c) crate::commands::log::LogRow and log::run for the log line format, (d) the Theme struct for color field names, and (e) config_schema or another tab for ratatui Line/Span/Paragraph idioms used in this codebase. IMPLEMENT per the plan snippet (adapt names to reality): ViewRenderData<'a> { view_op: ViewOperationKind, theme: &Theme, navbar_focused: bool, loading: bool, checkout: Option<(&[HostSnapshot], &DisplayColumns)>, list: Option<&ListData>, log: Option<&[LogRow]>, result_scroll: usize }. render_view draws a bordered block titled View and splits into selector(len 2) / target-summary(len 1) / result(min 0); implement render_view_selector (horizontal radio for checkout/list/log), render_view_target_summary (greyed line for Log since log has no target), and render_result_area dispatching to render_checkout_result / render_list_result / render_log_result. Each result renderer: respects result_scroll (skip that many lines), shows a 'loading…' placeholder when data.loading, and renders the log status glyph using THEME colors (not raw ANSI escapes — convert log::run's ANSI to themed Spans). NO unit tests for rendering (verified via manual checklist later); keep renderers pure. Annotate items unused until Task 11 with #[allow(dead_code)]. cargo build --features tui must compile; cargo test --features tui passes. Commit 'feat(tui): view_tab module with result renderers'. Build/test tui feature only. Do NOT modify app.rs render dispatch yet (that is Task 11) and leave unrelated in-flight edits alone.

## Rules

1. Work in `/Volumes/Home/Users/wen/repos/sshi`. Do not modify files outside what the task lists unless the task says to.
2. Follow any TDD steps the task names exactly: failing test → run → implement → run → commit.
3. Use the commit message the task specifies verbatim, if any.
4. If a step is ambiguous or the task contradicts the spec, STOP and return `status: BLOCKED` with notes.
5. Inspect-only commands are fine; do not let them mutate workspace state.

## Output contract

Your response MUST **end with** this YAML block (delimited by `---`, after any progress notes):

```yaml
---
status: COMPLETED | BLOCKED
files_changed:
  - <path relative to /Volumes/Home/Users/wen/repos/sshi>
notes: |
  <free-text summary; required even when COMPLETED>
---
```

- `COMPLETED`: all steps run, tests pass, commit created.
- `BLOCKED`: explain in `notes` (missing context, plan conflict, environment).
- `files_changed`: if unsure, paste `git diff --name-only HEAD`.
