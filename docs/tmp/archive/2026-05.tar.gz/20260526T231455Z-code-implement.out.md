The diff is clean and surgical. Summary of changes:

1. **`operate_tab.rs`**: Removed `run_yes` field from `OperateRenderData`. Updated layout to Approach-B order (selector → target summary → params → entries → execute). Replaced `render_target_row` with `render_target_summary` that includes skip info in 1 line. Made SecondFlag row exec-only in `render_run_exec_params`. Reduced param_rows for run from 7 to 5.

2. **`app.rs`**: Removed `run_yes: false` literal from `OperateRenderData` construction. Removed the no-op `(OperationKind::Run, ParamPanelField::SecondFlag)` key handler arm.

No View/Checkout rendering or unrelated code was touched. Build and all 179 tests pass.

---
status: COMPLETED
files_changed:
  - src/tui/tabs/operate_tab.rs
  - src/tui/app.rs
notes: |
  Removed `run_yes` from OperateRenderData and all its usages. Restructured render_operate to Approach-B vertical stack: op selector → target summary line (1 line, includes skip info) → specific params → applicable entries → execute button. SecondFlag (--keep) now renders for exec only; run shows only sudo. Removed dangling no-op key handler arm for run+SecondFlag. Build passes, 179 tests pass. Committed as 'feat(tui): Operate tab Approach-B layout (summary line, no --yes)'.
---
