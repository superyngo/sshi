# Implement Task


You are implementing one well-scoped task. The caller has delegated to you via `agd`. You may write files in `/Volumes/Home/Users/wen/repos/sshi` (the operator has enabled the required bypass flags in your `agd` config).

- **Repo:** `/Volumes/Home/Users/wen/repos/sshi`
- **Spec (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/specs/2026-05-26-tui-operate-refactor-design.md`
- **Plan (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/plans/2026-05-26-tui-operate-refactor.md`
- **Stage:** task 3: skip in target filter

**Load these skills before starting the task** (via your `Skill` tool if running inside Claude Code; otherwise read `~/.claude/skills/<name>/SKILL.md` and follow them): `test-driven-development`, `verification-before-completion`.

## Task

Task 3 from the plan: Add skip to TargetFilterState and apply as a final subtraction in resolution. Follow plan Task 3 Steps 1-7 exactly. Step1: add test skip_field_round_trips_and_defaults_empty in src/tui/state/persist.rs tests. Step2: verify fail. Step3: add 'pub skip: Vec<String>,' to TargetFilterState plus 'skip: Vec::new(),' in its Default impl. Step4: locate fn resolve_target_names in src/tui/app.rs (grep) and after it builds the host-name list, subtract the TUI skip modifier (names.retain(|n| !skip.iter().any(|s| s==n))) using the correct access path to target_filter.skip; if it is a free function add a skip:&[String] param and update call sites. Step5: add resolution test skip_subtracts_from_resolved_targets mirroring existing target-resolution test setup (build config with h1,h2,h3 in group g, mode=All, skip=[h2], assert resolved == [h1,h3]). Step6: run 'cargo test --features tui -p sshi skip_' confirm pass. Step7: commit 'feat(tui): add skip modifier to target filter + resolution'. Build/test tui feature only. Note: the CLI Context already has a skip field; this task is the TUI TargetFilterState.skip and its application in the TUI resolver only — do not change CLI behavior. Leave unrelated in-flight edits alone.

## Rules

1. Work in `/Volumes/Home/Users/wen/repos/sshi`. Do not modify files outside what the task lists unless the task says to.
2. Follow any TDD steps the task names exactly: failing test → run → implement → run → commit.
3. Use the commit message the task specifies verbatim, if any.
4. If a step is ambiguous or the task contradicts the spec, STOP and return `status: BLOCKED` with notes.
5. Inspect-only commands are fine; do not let them mutate workspace state.

## Output contract

Your response MUST **end with** this YAML block (delimited by `---`, after any progress notes):

```yaml
---
status: COMPLETED | BLOCKED
files_changed:
  - <path relative to /Volumes/Home/Users/wen/repos/sshi>
notes: |
  <free-text summary; required even when COMPLETED>
---
```

- `COMPLETED`: all steps run, tests pass, commit created.
- `BLOCKED`: explain in `notes` (missing context, plan conflict, environment).
- `files_changed`: if unsure, paste `git diff --name-only HEAD`.
