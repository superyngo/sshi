Clean build, no warnings.

```yaml
---
status: COMPLETED
files_changed:
  - src/tui/app.rs
  - CHANGELOG.md
notes: |
  Wired the View tab core into App as specified in Task 11a:

  1. **New App fields**: `view_op`, `view_list`, `view_log`, `view_dirty`, `view_loading`, `log_last`, `log_errors` — initialized from `persisted.operate` with `log_last` defaulting to 20 when persisted value is 0.

  2. **`refresh_view(&mut self)`**: builds a `Context` and dispatches to `maybe_reload_checkout()+apply_checkout_filter()` for Checkout, `list_core().unwrap_or_default()` for List, or `log_core().unwrap_or_default()` for Log. Sets `view_dirty=false` at end.

  3. **Render dispatch**: replaced `TabId::View` block — checks `view_dirty` then calls `refresh_view()`, builds `ViewRenderData` with only the active op's payload populated, calls `view_tab::render_view()`. Removed the now-dead `App::render_checkout` method (80 lines).

  4. **Key handling**: added Left/Right to cycle `view_op` (Checkout↔List↔Log) with `view_dirty=true`; disabled `f` filter key when `view_op==Log`; kept existing scroll keys (Up/Down/PgUp/PgDn/Home/End).

  5. **Updated all text**: help popup (Checkout→View), info popup, footer hints. Removed dead imports (`Cell`, `Row`, `Table`, `extract_metric_value`, `format_relative_time`, `metric_header`, `metric_width`).

  6. Build: zero warnings. Tests: 179 pass. No specific-param editing added (that's 11b).
---
```
