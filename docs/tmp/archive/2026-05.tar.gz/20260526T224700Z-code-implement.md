# Implement Task


You are implementing one well-scoped task. The caller has delegated to you via `agd`. You may write files in `/Volumes/Home/Users/wen/repos/sshi` (the operator has enabled the required bypass flags in your `agd` config).

- **Repo:** `/Volumes/Home/Users/wen/repos/sshi`
- **Spec (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/specs/2026-05-26-tui-operate-refactor-design.md`
- **Plan (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/plans/2026-05-26-tui-operate-refactor.md`
- **Stage:** task 5: rename Checkout tab to View

**Load these skills before starting the task** (via your `Skill` tool if running inside Claude Code; otherwise read `~/.claude/skills/<name>/SKILL.md` and follow them): `test-driven-development`, `verification-before-completion`.

## Task

Task 5 from the plan: Rename TabId::Checkout -> TabId::View and ActiveTab::Checkout -> ActiveTab::View with a serde alias so legacy state files still load. Follow plan Task 5 Steps 1-6 exactly. Step1: add test legacy_checkout_tab_loads_as_view in src/tui/state/persist.rs tests asserting toml with active_tab="Checkout" deserializes to ActiveTab::View. Step2: verify fail. Step3: in persist.rs rename ActiveTab variant Checkout->View, add #[serde(alias = "Checkout")] on the View variant (keep #[default] on View per the plan snippet), update from_tab_id/to_tab_id to use TabId::View/ActiveTab::View, and update existing persist.rs tests that assert ActiveTab::Checkout (empty_string_loads_as_default, malformed_file_returns_default, missing_file_returns_default) to ActiveTab::View. Step4: in src/tui/tabs/mod.rs rename TabId::Checkout->View (variant, ALL array, label to "3:View", next/prev), then replace EVERY TabId::Checkout / ActiveTab::Checkout occurrence in src/ (grep -rn 'TabId::Checkout|ActiveTab::Checkout' src/) with ::View. Step5: run 'cargo test --features tui -p sshi legacy_checkout_tab_loads_as_view && cargo build --features tui' confirm pass+compile. Step6: commit 'refactor(tui): rename Checkout tab to View (serde alias for state)'. Build/test tui feature only. Leave unrelated in-flight edits alone. Note: do NOT change rendering behavior yet (render_checkout stays); this task is purely the rename + alias.

## Rules

1. Work in `/Volumes/Home/Users/wen/repos/sshi`. Do not modify files outside what the task lists unless the task says to.
2. Follow any TDD steps the task names exactly: failing test → run → implement → run → commit.
3. Use the commit message the task specifies verbatim, if any.
4. If a step is ambiguous or the task contradicts the spec, STOP and return `status: BLOCKED` with notes.
5. Inspect-only commands are fine; do not let them mutate workspace state.

## Output contract

Your response MUST **end with** this YAML block (delimited by `---`, after any progress notes):

```yaml
---
status: COMPLETED | BLOCKED
files_changed:
  - <path relative to /Volumes/Home/Users/wen/repos/sshi>
notes: |
  <free-text summary; required even when COMPLETED>
---
```

- `COMPLETED`: all steps run, tests pass, commit created.
- `BLOCKED`: explain in `notes` (missing context, plan conflict, environment).
- `files_changed`: if unsure, paste `git diff --name-only HEAD`.
