# Implement Task


You are implementing one well-scoped task. The caller has delegated to you via `agd`. You may write files in `/Volumes/Home/Users/wen/repos/ssync` (the operator has enabled the required bypass flags in your `agd` config).

- **Repo:** `/Volumes/Home/Users/wen/repos/ssync`
- **Spec (optional):** `docs/superpowers/specs/2026-05-26-cli-interface-unification-design.md`
- **Plan (optional):** `docs/superpowers/plans/2026-05-26-cli-interface-unification.md`
- **Stage:** task 3: remove run/exec -y/--yes

**Load these skills before starting the task** (via your `Skill` tool if running inside Claude Code; otherwise read `~/.claude/skills/<name>/SKILL.md` and follow them): `test-driven-development`, `verification-before-completion`.

## Task

Implement Task 3 from the plan file (plan_path), Steps 1-10 exactly. TDD: first add failing tests run_rejects_yes and exec_rejects_yes to the #[cfg(test)] mod tests in src/cli.rs. Then: remove the yes flag block from Commands::Run and Commands::Exec in cli.rs; drop _yes param from run_core and yes param from the run handler + fix call site in src/commands/run.rs; drop _yes from exec_core and yes from exec handler + fix call site in src/commands/exec.rs; update Commands::Run and Commands::Exec match arms in src/main.rs; in src/tui/app.rs delete the orphaned 'let yes = self.run_yes;' local and drop the yes/false positional arg from the run_core and exec_core call sites. CRITICAL: leave the run_yes field, its checkbox, persistence, and help text UNTOUCHED (that inert toggle is scoped to a separate #4 refactor). Build with 'cargo build --features tui' to confirm all call sites including TUI compile. Run cargo test (expect all green). Commit with the exact message in Step 10.

## Rules

1. Work in `/Volumes/Home/Users/wen/repos/ssync`. Do not modify files outside what the task lists unless the task says to.
2. Follow any TDD steps the task names exactly: failing test → run → implement → run → commit.
3. Use the commit message the task specifies verbatim, if any.
4. If a step is ambiguous or the task contradicts the spec, STOP and return `status: BLOCKED` with notes.
5. Inspect-only commands are fine; do not let them mutate workspace state.

## Output contract

Your response MUST **end with** this YAML block (delimited by `---`, after any progress notes):

```yaml
---
status: COMPLETED | BLOCKED
files_changed:
  - <path relative to /Volumes/Home/Users/wen/repos/ssync>
notes: |
  <free-text summary; required even when COMPLETED>
---
```

- `COMPLETED`: all steps run, tests pass, commit created.
- `BLOCKED`: explain in `notes` (missing context, plan conflict, environment).
- `files_changed`: if unsure, paste `git diff --name-only HEAD`.
