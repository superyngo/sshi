---
status: COMPLETED
files_changed:
  - src/tui/state/persist.rs
  - src/tui/tabs/mod.rs
  - src/tui/app.rs
  - src/tui/focus.rs
notes: |
  Renamed TabId::Checkout → TabId::View and ActiveTab::Checkout → ActiveTab::View across all of src/. Added `#[serde(alias = "Checkout")]` on the View variant so legacy state files with `active_tab = "Checkout"` still deserialize correctly. New test `legacy_checkout_tab_loads_as_view` confirms backward compatibility. Updated existing test assertions from `ActiveTab::Checkout` to `ActiveTab::View`. Label changed to "3:View". All 168 tests pass, build succeeds. No rendering behavior changed — render functions still use their original names.
---
