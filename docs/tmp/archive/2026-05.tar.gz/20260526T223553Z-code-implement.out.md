Evidence confirms: commit `9bd155a` with exact message, both files changed, all 5 skip-related tests pass, 167 total suite tests pass.

---
status: COMPLETED
files_changed:
  - src/tui/state/persist.rs
  - src/tui/app.rs
notes: |
  Task 3 completed following TDD: wrote `skip_field_round_trips_and_defaults_empty` test (failed — no `skip` field), added `pub skip: Vec<String>` to `TargetFilterState` + `Default` impl (test passed), added `skip: &[String]` param to `resolve_target_names` with `names.retain(|n| !skip.iter().any(|s| s == n))` and updated all 6 call sites, added `skip_subtracts_from_resolved_targets` resolution test (all pass). Commit `9bd155a` with message "feat(tui): add skip modifier to target filter + resolution". Full suite: 167 passed, 0 failed.
---
