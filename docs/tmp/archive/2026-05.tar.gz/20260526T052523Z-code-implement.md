# Implement Task


You are implementing one well-scoped task. The caller has delegated to you via `agd`. You may write files in `/Volumes/Home/Users/wen/repos/ssync` (the operator has enabled the required bypass flags in your `agd` config).

- **Repo:** `/Volumes/Home/Users/wen/repos/ssync`
- **Spec (optional):** `docs/superpowers/specs/2026-05-26-cli-interface-unification-design.md`
- **Plan (optional):** `docs/superpowers/plans/2026-05-26-cli-interface-unification.md`
- **Stage:** task 5: add check --dry-run

**Load these skills before starting the task** (via your `Skill` tool if running inside Claude Code; otherwise read `~/.claude/skills/<name>/SKILL.md` and follow them): `test-driven-development`, `verification-before-completion`.

## Task

Implement Task 5 from the plan file (plan_path), Steps 1-9 exactly. TDD: first add failing test check_parses_dry_run to the #[cfg(test)] mod tests in src/cli.rs. Then add a 'dry_run: bool' #[arg(long)] field to Commands::Check (between target and output flatten) in cli.rs; thread dry_run through the Commands::Check match arm in src/main.rs; add 'dry_run: bool' param to the check::run handler (between ctx and output) in src/commands/check.rs and insert the preview block at the very top of the body BEFORE the existing host_configs_empty_hint block — it resolves hosts, calls the existing build_host_check_configs(ctx, &hosts) helper, and for each host prints via printer::print_host_line either 'would collect: <enabled joined>' when enabled checks are non-empty else 'no checks apply' (skip), then returns Ok(()) before any SSH connection or DB write. Build, run cargo test (expect all green), and verify on the real binary: 'cargo run -- check --all --dry-run' prints per-host preview lines with NO snapshot rows written (cross-check 'cargo run -- log --last 5'). Commit with the exact message in Step 9. Use the verbatim commit message from the plan including the Claude Opus 4.7 co-author line.

## Rules

1. Work in `/Volumes/Home/Users/wen/repos/ssync`. Do not modify files outside what the task lists unless the task says to.
2. Follow any TDD steps the task names exactly: failing test → run → implement → run → commit.
3. Use the commit message the task specifies verbatim, if any.
4. If a step is ambiguous or the task contradicts the spec, STOP and return `status: BLOCKED` with notes.
5. Inspect-only commands are fine; do not let them mutate workspace state.

## Output contract

Your response MUST **end with** this YAML block (delimited by `---`, after any progress notes):

```yaml
---
status: COMPLETED | BLOCKED
files_changed:
  - <path relative to /Volumes/Home/Users/wen/repos/ssync>
notes: |
  <free-text summary; required even when COMPLETED>
---
```

- `COMPLETED`: all steps run, tests pass, commit created.
- `BLOCKED`: explain in `notes` (missing context, plan conflict, environment).
- `files_changed`: if unsure, paste `git diff --name-only HEAD`.
