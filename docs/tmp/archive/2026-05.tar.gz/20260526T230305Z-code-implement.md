# Implement Task


You are implementing one well-scoped task. The caller has delegated to you via `agd`. You may write files in `/Volumes/Home/Users/wen/repos/sshi` (the operator has enabled the required bypass flags in your `agd` config).

- **Repo:** `/Volumes/Home/Users/wen/repos/sshi`
- **Spec (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/specs/2026-05-26-tui-operate-refactor-design.md`
- **Plan (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/plans/2026-05-26-tui-operate-refactor.md`
- **Stage:** task 7: create operate_schema.rs

**Load these skills before starting the task** (via your `Skill` tool if running inside Claude Code; otherwise read `~/.claude/skills/<name>/SKILL.md` and follow them): `test-driven-development`, `verification-before-completion`.

## Task

Task 7 from the plan: Create src/tui/tabs/operate_schema.rs producing FieldDescriptors for each operation's specific params and applying edits via an OpSpecific state-view struct. Follow plan Task 7 Steps 1-6 exactly. CRITICAL FIRST: read src/tui/tabs/config_schema.rs to learn the REAL API of FieldDescriptor and FieldKind — the exact constructor (is it FieldDescriptor::scalar(key, value, kind)? what are its arg types/lifetimes?) and the real FieldKind variant names (the plan assumes Bool, Enum{variants:Vec<&str>}, U64 — VERIFY these exact names and shapes; adapt the snippet to the actual enum, e.g. if it's FieldKind::Number or variants:Vec<String>). Also read state/persist.rs for OperationKind/SyncMode/ViewOperationKind and components/input_field.rs for InputField. Step1: define the OpSpecific<'a> struct per the plan snippet (mutable refs: sudo, keep, dry_run, sync_mode, checkout_history, log_last, log_errors). Step2: add tests check_specific_fields_has_dry_run and apply_run_sudo_toggles per the plan. Step3: verify fail. Step4: implement check/run/exec/sync/checkout/log _specific_fields fns and apply_specific(s,op,key,val) per the plan snippet (adapted to the real FieldKind API), plus an apply_view_specific(view_op,key,val) following the same total/no-op-on-unknown pattern for history/last/errors/action. Register 'pub mod operate_schema;' in src/tui/tabs/mod.rs. Use #[allow(dead_code)] on items not yet consumed if the build warns (they get wired in Tasks 9/11). Step5: run 'cargo test --features tui -p sshi -- _specific_fields apply_' and 'cargo build --features tui' confirm pass+compile. Step6: commit 'feat(tui): operate_schema for operation-specific fields'. Build/test tui feature only. Leave unrelated in-flight edits alone.

## Rules

1. Work in `/Volumes/Home/Users/wen/repos/sshi`. Do not modify files outside what the task lists unless the task says to.
2. Follow any TDD steps the task names exactly: failing test → run → implement → run → commit.
3. Use the commit message the task specifies verbatim, if any.
4. If a step is ambiguous or the task contradicts the spec, STOP and return `status: BLOCKED` with notes.
5. Inspect-only commands are fine; do not let them mutate workspace state.

## Output contract

Your response MUST **end with** this YAML block (delimited by `---`, after any progress notes):

```yaml
---
status: COMPLETED | BLOCKED
files_changed:
  - <path relative to /Volumes/Home/Users/wen/repos/sshi>
notes: |
  <free-text summary; required even when COMPLETED>
---
```

- `COMPLETED`: all steps run, tests pass, commit created.
- `BLOCKED`: explain in `notes` (missing context, plan conflict, environment).
- `files_changed`: if unsure, paste `git diff --name-only HEAD`.
