---
status: COMPLETED
files_changed:
  - src/tui/components/target_filter.rs
notes: |
  Added Skip row to FilterPopup mirroring the Groups/Hosts vec pattern:
  - Added `Field::Skip` variant to the focus enum
  - Inserted `Field::Skip` in `fields_in_order()` between Shell/mode rows and SerialToggle
  - Handled `Field::Skip` in `toggle_focused`, `activate_focused`, and `cycle_chip` (←/→ seeds first host into skip list, same as hosts pattern)
  - Added skip row to render layout (one extra Constraint::Length(1)) and rendered " Skip: <chips>" line
  - `cargo build --features tui` passes cleanly
  - Committed as 'feat(tui): add skip row to target filter popup'
---
