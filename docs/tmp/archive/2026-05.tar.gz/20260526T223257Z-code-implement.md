# Implement Task


You are implementing one well-scoped task. The caller has delegated to you via `agd`. You may write files in `/Volumes/Home/Users/wen/repos/sshi` (the operator has enabled the required bypass flags in your `agd` config).

- **Repo:** `/Volumes/Home/Users/wen/repos/sshi`
- **Spec (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/specs/2026-05-26-tui-operate-refactor-design.md`
- **Plan (optional):** `/Volumes/Home/Users/wen/repos/sshi/docs/superpowers/plans/2026-05-26-tui-operate-refactor.md`
- **Stage:** task 2: extract log_core

**Load these skills before starting the task** (via your `Skill` tool if running inside Claude Code; otherwise read `~/.claude/skills/<name>/SKILL.md` and follow them): `test-driven-development`, `verification-before-completion`.

## Task

Task 2 from the plan: Extract log_core from log::run in src/commands/log.rs. Follow plan Task 2 Steps 1-5 exactly: add tests (parse_since_relative_days and log_core_empty_db_returns_no_rows — if Context::for_test does not exist, build Context inline matching the struct's public fields as the list.rs test does: config AppConfig::default(), config_path None, db from crate::state::db::open(None), timeout 30, mode TargetMode::All, serial false, skip vec![], verbose false), verify failure, add the LogRow struct and log_core(ctx,last,since,host,action,errors)->Result<Vec<LogRow>> as in the plan, rewrite run to format/print from rows preserving current stdout exactly, run 'cargo test --features tui -p sshi log_core && cargo test --features tui' to confirm pass, then commit 'refactor(log): extract log_core query fn from run'. IMPORTANT: log_core must preserve run's exact existing behavior — verify the original run's query/binding/printing logic and replicate it faithfully (do not introduce behavior changes). Build/test with tui feature only. Leave unrelated in-flight edits alone.

## Rules

1. Work in `/Volumes/Home/Users/wen/repos/sshi`. Do not modify files outside what the task lists unless the task says to.
2. Follow any TDD steps the task names exactly: failing test → run → implement → run → commit.
3. Use the commit message the task specifies verbatim, if any.
4. If a step is ambiguous or the task contradicts the spec, STOP and return `status: BLOCKED` with notes.
5. Inspect-only commands are fine; do not let them mutate workspace state.

## Output contract

Your response MUST **end with** this YAML block (delimited by `---`, after any progress notes):

```yaml
---
status: COMPLETED | BLOCKED
files_changed:
  - <path relative to /Volumes/Home/Users/wen/repos/sshi>
notes: |
  <free-text summary; required even when COMPLETED>
---
```

- `COMPLETED`: all steps run, tests pass, commit created.
- `BLOCKED`: explain in `notes` (missing context, plan conflict, environment).
- `files_changed`: if unsure, paste `git diff --name-only HEAD`.
