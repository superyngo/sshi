# Prompt audit — sshi (2026-09-29)

## Assumptions (Step 0)

- **Scope:** the repository's agent-config surface: `AGENTS.md`, `.github/copilot-instructions.md`.
  No `CLAUDE.md`, `.claude/` rules/skills/commands/agents, or skills exist in the repo.
  `.claude/settings.local.json` was not read (it may hold secrets).
  Skipped because they are outside the project: `~/.claude/CLAUDE.md` and the auto-memory files. Re-run with those files named to include them.
- **Target model:** Claude Opus 5.5 (the model running this audit). sshi is an SSH fan-out tool and does not call any LLM API.
  The only provider string, `~/.gemini/oauth_creds.json` in `src/output/summary.rs:435`, is a file-path fixture and not an API call.
- **Groups:** Group 1 (dated prompt text): 0 findings. Group 2 (brittle config files): 1 finding plus 1 flag.
  Group 3 (tool descriptions): not applicable. Group 4 (request config): not applicable.

## Summary

This surface is in good shape. The Sep 25–26 correction commits (`fc5af62`, `f2cf693`) keep it close to the code.
Every checked claim holds, including `*_core` + `ProgressSink` + typed reports, no `printer` calls inside core fns,
no `print!` in `src/tui/`, `ci.yml` running fmt/clippy/test on ubuntu+macos with `-D warnings`,
`HostEntry`, rusqlite `open_in_memory`, and `docs/reference/changelog/`.
There is one real finding: the import example contradicts both `cargo fmt` and the repository's actual layout.

## Findings

### 1. The import example gets reordered by `cargo fmt` (High)

- **Location:** `AGENTS.md:55-64`
- **Evidence:** the example lists `use std::…; use anyhow::…; use tokio::…; use crate::…;` as contiguous lines, with no blank lines between them.
- **Pattern:** Group 2, volatile specifics: a claim the repository contradicts.
- **Why obsolete:** there is no `rustfmt.toml`, so rustfmt sorts each contiguous block.
  Running `rustfmt` on the example exactly as written puts `crate` first: `crate`, `anyhow`, `std`, `tokio`.
  That breaks the stated std→third-party→local order, and CI runs `cargo fmt --check`.
  The real code (e.g. `src/commands/cp.rs:7-15`, `src/commands/sync/mod.rs:9-20`) separates the groups with blank lines, which is what keeps the order.
  "std extern crates" also reads as a single group.
- **Action:** rewrite (see the diff below). This is proposed only, per the Group 2 rule.

### 2. Naming conventions are already enforced by rustc (Low, flag)

- **Location:** `AGENTS.md:67-69`
- **Evidence:** "Use `snake_case` for functions…", "`PascalCase` for structs…", "`SCREAMING_SNAKE_CASE` for constants".
- **Pattern:** Group 2, a verbose section explaining things the model already knows.
- **Why:** these are Rust defaults, and rustc's naming lints plus `-D warnings` in CI already enforce them.
  The lines are harmless, the file also serves human contributors, and keep-list item 2 applies (cruft is not the same as length). No edit is proposed.

## Proposed diff

```diff
--- a/AGENTS.md
+++ b/AGENTS.md
@@ -54,13 +54,16 @@
 ### Imports
-- Group imports: std extern crates -> third-party -> local modules
+- Group imports: std -> third-party crates -> local (`crate::`) modules, with a blank line
+  between groups (`cargo fmt` sorts within each contiguous block, so the blank lines keep the order)
 - Use `use crate::module::item` for local imports
 - Keep imports at file top, sorted alphabetically within groups
 - Example:
   ```rust
   use std::path::PathBuf;
+
   use anyhow::{Context, Result};
   use tokio::process::Command;
+
   use crate::config::schema::HostEntry;
   ```
```

No edits were applied.
