# Goal: fix all open backlog items + new findings (2026-09-25)

User instruction: "fix all left items and new items found all way along" (goal mode = blanket
approval; conservative option chosen where a finding offers alternatives, stated in changelog).

## Method
- Wave 1: six worktree agents under `../sshi-wt/<Name>` (branch `wt/<Name>`), target dirs APFS-cloned
  from main. Agents commit one commit per item WITHOUT CHANGELOG/BACKLOG; integrator cherry-picks
  onto main, amends with CHANGELOG + BACKLOG Done row, then `docs: record Bxx closing commit`.
- Real-binary rig `/tmp/b32` shared; each agent uses `~/<Name>/` remote paths and `/tmp/<Name>/`.
- Wave 2 (after wave 1 merged): B53, B54, B55, B9, B64, new findings.

| Agent | Items |
|---|---|
| SyncFixes | B34 B18 B62 B19 B58 B65 |
| ProbeFixes | B39 B40 B59 B10 B41 |
| CmdFixes | B37 B38 B60 B31 B69 |
| HostFixes | B42 B30 B8 B15 B16 |
| TuiConfigFixes | B3 B4 B45 B46 B61 B11 B48 |
| TuiAppFixes | B50 B51 B52 B68 B70 B49 B17 B12 B6 B47 |

## Log
- 868d6b6: repaired backlog (Done rows B66/B43/B13/B14/B36 had landed in the Open table because
  the insert matched the tail of the 8-column separator). Insert helper now anchors on
  `| ID | Finding | Closed by |`.
- Worktrees must be removed only with user approval (no permanent deletion rule).
- 9841414: B9 done by integrator in main while wave 1 runs.
- 8c4d5ee: B64 (ratatui 0.30, crossterm 0.29, indicatif 0.18, anyhow 1.0.104); rsa row in Awaiting external. TUI smoke /tmp/b64/smoke.py identical.
- INCIDENT: agents' relative paths resolved to MAIN checkout -> stray edits in main; a docs commit briefly swallowed them (undone before push, backup /tmp/main-stray-*.patch). Broadcast told agents to use absolute worktree paths. Helpers now assert main clean + never use `commit -a`.
- NEW FINDING (to log as next B id): CI annotation "Node.js 20 is deprecated … actions/checkout@v4". ci.yml: checkout@v4; release.yml: checkout@v4, upload-artifact@v4, download-artifact@v4, softprops/action-gh-release@v1 (node16). Latest (all node24): checkout v7.0.1, upload-artifact v7.0.1, download-artifact v8.0.1, action-gh-release v3.0.3, rust-cache v2.9.2. Check breaking changes per major before bumping; release.yml verifiable only via tag or workflow_dispatch.
- Integrated so far (main): B41 B8 B3 B18 B60 B62 B10 B16 B45 B51 B68 B59 B38 (+B9 B64 B71 by me). B72 logged (sync shutdown Arc) → SyncFixes. B53/B54 design saved in 2026-09-25-B53-B54-design.md.
- ~22:23 local: ALL subagents died (gemini quota 429, resets 2026-09-25T18:54Z). Integrator continues alone.
  Integrated by then: B41 B8 B3 B18 B60 B62 B10 B16 B45 B51 B68 B59 B38 B15 B70 B61 B49 B52 B39 B40 B42 (+B9 B64 B71).
  Leftovers in worktrees: CmdFixes ef77ee5 (B37, needs alias cleanup) + uncommitted edits (alias cleanup/B31 in host/shell.rs);
  SyncFixes e000a11 (B34, needs chunking) + uncommitted collect.rs (chunking WIP); HostFixes B30 partial saved /tmp/b30-partial.patch
  (was accidentally inside B42 fixup commit 2ffe886; split out before push).
  Remaining: B37 B34 B19 B58 B65 B72 B31 B69 B30 B4 B46 B48 B11 B6 B17 B47 B12 B50 B53 B54 B55 + new B73 (macOS swap not collected: sh swap probe is `free -b` only).
- IPython gotcha: a line starting with `!` inside a python string in eval gets turned into a shell call. Edit Rust with the edit tool when lines start with `!`.
- Done by integrator after quota loss: B37 B34(+chunking, per-chunk timeout) B72 B58 B19(no DROP; Awaiting external) B65 B31 B69(Context::verbose removed) B30 B73.
- Done by integrator (cont.): B6 B17 B74(new) B47 B12(pending Windows verification) B50 B4 B48 B11. Remaining: B46, B54, B53, B55.
- NOTE: accidental rig artifact (unquoted ~ expanded locally) moved to ~/.Trash/INTEG53-sshi-rig-artifact (not deleted).

## 2026-09-26 session tail (after context compaction)
- B53 closed as four pushed commits (6a265eb, b0562ee, 98506ce, 13ccb55) + e38f3bc; squash dropped because 4/4 was committed via helper after 1-3 were already on main locally — history kept as is.
- Pending "one SFTP channel per host" verified on rig (sshd VERBOSE: 1 command + 2 sftp sessions per host for 120 files) → Done row, dc9cbd0.
- New: B75 (global/Include-leading ssh_config options) 380b938; B76 (release.yml shell hardening) 61c2681; B77 (temp-name collision on shared FS) 2463499.
- AGENTS.md core-return wording updated f2cf693.
- Open for user: remove ../sshi-wt/* worktrees + wt/* branches? add migration 003 DROP TABLE sync_state? B12 needs real Windows check.

## Worktree removal 20260926-072232 (user chose 'Remove all' 2026-09-26)
Dirs moved to ~/.Trash/sshi-wt-20260926-072232/<name> (uncommitted edits preserved there). Branch tips (restore: git branch <name> <sha>):
- wt/CmdFixes ef77ee5164440d3614f8ba21c3fbd619d1441243
- wt/Deps 4630079253ae6536ec5e7d1af653f59ffea368d9
- wt/HostFixes 2ffe8868aa410b8919a807aaf872f7714fa0cc6f
- wt/InputFixes e9ec611345d3d18f2f57e3d880cd207bc9c5b8c9
- wt/ProbeFixes 0892d8fd2bf6908f8a1ef70f6f596978344697b2
- wt/SyncFixes e000a11a951d0488e04d219e88f41ee7211894a3
- wt/TuiAppFixes 46ac4cc45c46154b6418d0f8e216f7db0f701136
- wt/TuiConfigFixes 9c5b3ec63006c5b0c26b3636507220b76d6b0db7
- wt/TuiEditFixes e9ec611345d3d18f2f57e3d880cd207bc9c5b8c9
