# Shared context for sshi fix agents (integrator: main session)

## Goal
Close open backlog items in the Rust CLI/TUI crate `sshi`. The user approved fixing every open item.
Rows live in `docs/plan/BACKLOG.md` (Open table: finding, evidence symbols, acceptance column);
details per ID in `docs/audit/2026-09-25-code-audit.md` (search the ID). Read `AGENTS.md` and
`CONTEXT.md` first; reference docs are `docs/reference/*.md`.

## HARD RULE: paths
Your tools' RELATIVE paths and default bash cwd resolve to the MAIN checkout
`/Volumes/Home/Users/wen/repos/sshi` — which you must NEVER modify. Every read/edit/write/grep
path must be ABSOLUTE and start with your worktree `/Volumes/Home/Users/wen/repos/sshi-wt/<YourName>/`,
and every bash call must set `cwd` to your worktree. Check `git -C <worktree> status` after edits.

## Constraints
- Work only in your worktree (branch `wt/<YourName>`, from current `main`, warm `target/`). Never
  `git stash`, never push, never rebase/reset away commits, never delete files outside your worktree
  and `/tmp/<YourName>/`. `git rm` of a dead source file is fine when your item says so.
- Minimal, surgical changes; match existing style. `///` docs on public items. In docs cite code by
  symbol, never `file:line`. Never edit `docs/adr/*`. Update `docs/reference/*.md`, `README.md`,
  `CONTEXT.md`, `AGENTS.md` when behaviour they describe changes.
- DO NOT edit `CHANGELOG.md` or `docs/plan/BACKLOG.md` (integrator does).
- TUI rule (AGENTS.md): no print macros under `src/tui/`.
- Tools: `rg`; Python via `uv run --python 3.14 python3` (`--with pyte` for TUI screen scraping);
  no `timeout` binary (use `perl -e 'alarm N; exec @ARGV' cmd ...`).

## Per-item workflow
1. Diagnose: confirm the finding still holds; if not, report `skipped` with evidence.
2. User-observable CLI bug → reproduce on the real binary first (`cargo build -q`; run
   `target/debug/sshi`). TUI-only items: unit tests are the evidence; a pyte screen scrape
   (see `/tmp/b64/smoke.py` for a driver) is a bonus.
3. Write a test for the acceptance criterion, see it fail, then fix.
4. When a finding offers alternatives, choose the conservative standard option; say why.
5. Checks once per item at its end, zero warnings: `cargo fmt && cargo test -q && cargo test -q
   --no-default-features && cargo clippy -q --all-targets -- -D warnings && cargo clippy -q
   --all-targets --no-default-features -- -D warnings`.
6. One commit per item: `fix: <summary> (Bxx)` (`refactor:` when not a bug).
7. Adjacent problems: don't fix; report as new findings.
8. Commit each item as soon as it is done (budget limits can end your run; committed work survives).

## Real-binary rig (shared)
sshd on 127.0.0.1:22232 (`pgrep -f 'sshd -f /tmp/b32/sshd_config' || /usr/sbin/sshd -f
/tmp/b32/sshd_config -E /tmp/b32/sshd.log`). SSH aliases `h1`, `h2` in `/tmp/b32/home/.ssh/config`;
remote `$HOME` = `/tmp/b32/r1`, `/tmp/b32/r2`. Use only remote paths under `~/<YourName>/` and a
private config/state under `/tmp/<YourName>/` (copy `/tmp/b32/c.toml`, set `state_dir`). Run:
`HOME=/tmp/b32/home <worktree>/target/debug/sshi -c /tmp/<YourName>/c.toml <cmd> -a ...`.

## Report (final output)
Per ID: `status` (committed | partial | skipped | deferred), `commit` (full sha), `changelog`
(one line, repo style, before→after, ends with "(Bxx)."), `done_finding`, `done_note` (key
symbols + verification), `verification`, `decision`. Plus `new_findings` (finding, evidence,
priority, size, acceptance).
